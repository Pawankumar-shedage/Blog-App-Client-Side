import "../Components/UserProfile.css";
import { Base } from "./Base";

export const UserProfile = () => {
  return (
    <>
      <Base>
        <h1>UserProfile</h1>
      </Base>
    </>
  );
};
